package com.example.accessagent;

import android.app.*;
import android.os.*;
import android.content.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class AgentService extends Service {
    volatile boolean run = false, shown = false;
    ExecutorService loopEx = Executors.newSingleThreadExecutor();
    ExecutorService actionEx = Executors.newSingleThreadExecutor();
    String s, r, t;

    public int onStartCommand(Intent i, int f, int id) {
        String a = i == null ? "" : i.getAction();

        if ("STOP".equals(a)) {
            run = false;
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if ("DECIDE".equals(a)) {
            boolean allow = i.getBooleanExtra("allow", false);

            // ALLOW/DENY must use a different executor from the long-running poll loop.
            actionEx.execute(() -> {
                JSONObject body = new JSONObject();
                try { body.put("allow", allow); } catch (JSONException ignored) {}
                post("/api/agent/" + r + "/decision", body);
                shown = false;
            });
            return START_NOT_STICKY;
        }

        if ("START".equals(a) && !run) {
            var p = getSharedPreferences("a", 0);
            s = p.getString("s", "");
            r = p.getString("r", "");
            t = p.getString("t", "");

            startForeground(1, n("Accessibility Agent running"));
            run = true;
            loopEx.execute(this::loop);
        }

        return START_NOT_STICKY;
    }

    void loop() {
        post("/api/agent/" + r + "/register", new JSONObject());

        while (run) {
            try {
                JSONObject j = get("/api/agent/" + r + "/poll");

                if (j.optBoolean("pending") && !shown) {
                    shown = true;
                    Intent approval = new Intent(this, ApprovalActivity.class);
                    approval.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(approval);
                }

                if (j.optBoolean("approved")
                        && j.has("command")
                        && !j.isNull("command")) {
                    cmd(j.getJSONObject("command"));
                }

                Thread.sleep(900);
            } catch (Exception e) {
                try { Thread.sleep(2000); } catch (Exception ignored) {}
            }
        }
    }

    void cmd(JSONObject c) {
        String id = c.optString("id");
        String type = c.optString("type");
        JSONObject p = c.optJSONObject("payload");
        if (p == null) p = new JSONObject();

        ControlService a = ControlService.I;
        boolean ok = false;
        String m = "";
        String imageData = null;

        try {
            if (a == null) throw new Exception("Accessibility not enabled");

            switch (type) {
                case "home":
                    ok = a.home(); m = "Home"; break;
                case "back":
                    ok = a.back(); m = "Back"; break;
                case "tap":
                    ok = a.tap((float)p.optDouble("x"), (float)p.optDouble("y"));
                    m = "Tap"; break;
                case "swipe":
                    ok = a.swipe(
                            (float)p.optDouble("x1"), (float)p.optDouble("y1"),
                            (float)p.optDouble("x2"), (float)p.optDouble("y2"),
                            p.optLong("duration", 350));
                    m = "Swipe"; break;
                case "text":
                    ok = a.text(p.optString("text", ""));
                    m = ok ? "Text" : "No editable focused field";
                    break;
                case "click_text":
                    ok = a.clickText(p.optString("text", ""));
                    m = ok ? "UI text clicked" : "Matching clickable UI not found";
                    break;
                case "current_app":
                    String pkg = a.currentPackage();
                    ok = !pkg.isEmpty();
                    m = ok ? pkg : "Current package unavailable";
                    break;
                case "screenshot":
                    imageData = a.screenshotDataUrl();
                    ok = imageData != null;
                    m = "Screenshot captured";
                    break;
                default:
                    m = "Unsupported command";
            }
        } catch (Exception e) {
            m = e.getMessage();
        }

        JSONObject body = new JSONObject();
        try {
            body.put("commandId", id);
            body.put("ok", ok);
            body.put("message", m);
            if (imageData != null) body.put("imageData", imageData);
        } catch (JSONException ignored) {}

        post("/api/agent/" + r + "/result", body);
    }

    JSONObject get(String p) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(s + p).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Authorization", "Bearer " + t);
        return read(c);
    }

    JSONObject post(String p, JSONObject b) {
        try {
            HttpURLConnection c = (HttpURLConnection)new URL(s + p).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Authorization", "Bearer " + t);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStreamWriter w = new OutputStreamWriter(c.getOutputStream())) {
                w.write(b.toString());
            }
            return read(c);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    JSONObject read(HttpURLConnection c) throws Exception {
        int status = c.getResponseCode();
        InputStream in = status >= 200 && status < 300 ? c.getInputStream() : c.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        StringBuilder x = new StringBuilder();
        String l;
        while ((l = br.readLine()) != null) x.append(l);
        if (status < 200 || status >= 300) throw new IOException("HTTP " + status + ": " + x);
        return new JSONObject(x.toString());
    }

    Notification n(String x) {
        if (Build.VERSION.SDK_INT >= 26) {
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(new NotificationChannel(
                            "a", "Accessibility Agent", NotificationManager.IMPORTANCE_LOW));
        }

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "a")
                : new Notification.Builder(this);

        return b.setContentTitle("Accessibility Agent")
                .setContentText(x)
                .setSmallIcon(R.drawable.ic_status)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        run = false;
        loopEx.shutdownNow();
        actionEx.shutdownNow();
        super.onDestroy();
    }

    public android.os.IBinder onBind(Intent i) { return null; }
}
