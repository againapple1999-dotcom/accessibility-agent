package com.example.accessagent;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.Display;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class ControlService extends AccessibilityService {
    public static volatile ControlService I;

    @Override
    public void onServiceConnected() {
        I = this;
    }

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        I = null;
        super.onDestroy();
    }

    public boolean home() {
        return performGlobalAction(GLOBAL_ACTION_HOME);
    }

    public boolean back() {
        return performGlobalAction(GLOBAL_ACTION_BACK);
    }

    public boolean tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription s =
                new GestureDescription.StrokeDescription(p, 0, 80);
        return dispatchGesture(
                new GestureDescription.Builder().addStroke(s).build(),
                null,
                null
        );
    }

    public boolean swipe(float x1, float y1, float x2, float y2, long d) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        GestureDescription.StrokeDescription s =
                new GestureDescription.StrokeDescription(p, 0, d);
        return dispatchGesture(
                new GestureDescription.Builder().addStroke(s).build(),
                null,
                null
        );
    }

    public boolean text(String s) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        AccessibilityNodeInfo node =
                root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (node == null || !node.isEditable()) return false;

        Bundle b = new Bundle();
        b.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                s
        );
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || text == null || text.trim().isEmpty()) return false;

        List<AccessibilityNodeInfo> nodes =
                root.findAccessibilityNodeInfosByText(text);

        if (nodes == null) return false;

        for (AccessibilityNodeInfo node : nodes) {
            AccessibilityNodeInfo cur = node;
            int depth = 0;

            while (cur != null && depth < 8) {
                if (cur.isClickable()
                        && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
                cur = cur.getParent();
                depth++;
            }
        }
        return false;
    }

    public String currentPackage() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return "";
        return root.getPackageName().toString();
    }

    public String screenshotDataUrl() throws Exception {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            throw new Exception("Screenshot requires Android 11+");
        }

        CountDownLatch latch = new CountDownLatch(1);
        final String[] output = new String[1];
        final Exception[] error = new Exception[1];

        takeScreenshot(
                Display.DEFAULT_DISPLAY,
                getMainExecutor(),
                new TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(ScreenshotResult result) {
                        try {
                            Bitmap hardware = Bitmap.wrapHardwareBuffer(
                                    result.getHardwareBuffer(),
                                    result.getColorSpace()
                            );

                            if (hardware == null) {
                                throw new Exception("Screenshot bitmap conversion failed");
                            }

                            Bitmap bitmap =
                                    hardware.copy(Bitmap.Config.ARGB_8888, false);

                            ByteArrayOutputStream bos =
                                    new ByteArrayOutputStream();

                            bitmap.compress(
                                    Bitmap.CompressFormat.JPEG,
                                    55,
                                    bos
                            );

                            output[0] =
                                    "data:image/jpeg;base64,"
                                    + Base64.encodeToString(
                                            bos.toByteArray(),
                                            Base64.NO_WRAP
                                    );

                            result.getHardwareBuffer().close();
                        } catch (Exception e) {
                            error[0] = e;
                        } finally {
                            latch.countDown();
                        }
                    }

                    @Override
                    public void onFailure(int errorCode) {
                        error[0] =
                                new Exception(
                                        "Screenshot failed, code " + errorCode
                                );
                        latch.countDown();
                    }
                }
        );

        if (!latch.await(10, TimeUnit.SECONDS)) {
            throw new Exception("Screenshot timed out");
        }

        if (error[0] != null) throw error[0];
        if (output[0] == null) throw new Exception("Screenshot returned no image");

        return output[0];
    }
}
