package com.example.accessagent;
import android.app.*;import android.os.*;import android.content.*;
public class ApprovalActivity extends Activity{
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_approval);findViewById(R.id.allow).setOnClickListener(v->d(true));findViewById(R.id.deny).setOnClickListener(v->d(false));}
 void d(boolean a){Intent i=new Intent(this,AgentService.class);i.setAction("DECIDE");i.putExtra("allow",a);startService(i);finish();}
}