package com.example.accessagent;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import org.json.JSONObject;
import java.io.*;
import java.net.*;

/** MediaProjection recording: never starts without fresh Android consent. */
public class RecordingService extends Service {
    public static volatile boolean isRecording = false;
    public static volatile String activeId = "";
    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaRecorder recorder;
    private File file;
    private String recordId;
    private boolean stopping = false;
    private boolean recorderStarted = false;
    private static final int NOTIFICATION_ID = 2;
    private static final int MAX_DURATION_MS = 120000;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if ("STOP_RECORDING".equals(action)) { finishRecording(); return START_NOT_STICKY; }
        if ("RETRY_UPLOAD".equals(action)) { retryUpload(); return START_NOT_STICKY; }
        if (!"START_RECORDING".equals(action) || isRecording || recorderStarted) return START_NOT_STICKY;
        recordId = intent.getStringExtra("recordId");
        if (recordId == null) return START_NOT_STICKY;
        try {
            showForeground("Recording screen — 480p, max 2 min", true);
            Intent captureData = intent.getParcelableExtra("captureData");
            int result = intent.getIntExtra("captureResult", Activity.RESULT_CANCELED);
            if (captureData == null || result != Activity.RESULT_OK) throw new IOException("Screen capture consent missing");
            MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mgr.getMediaProjection(result, captureData);
            if (projection == null) throw new IOException("MediaProjection unavailable");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(() -> finishRecording()); }
            }, main);

            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            boolean portrait = dm.heightPixels >= dm.widthPixels;
            int width = portrait ? 480 : 848;
            int height = portrait ? 848 : 480;
            file = new File(getCacheDir(), "screen-record-" + recordId + ".mp4");
            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(width, height);
            recorder.setVideoFrameRate(15);
            recorder.setVideoEncodingBitRate(650_000);
            recorder.setOutputFile(file.getAbsolutePath());
            recorder.prepare();
            virtualDisplay = projection.createVirtualDisplay("Approved screen recording",
                    width, height, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    recorder.getSurface(), null, main);
            if (virtualDisplay == null) throw new IOException("Virtual display unavailable");
            recorder.start();
            recorderStarted = true;
            isRecording = true;
            activeId = recordId;
            final String id = recordId;
            new Thread(() -> {
                try { postJson("/record/started", "{\"recordId\":\"" + id + "\"}"); }
                catch (Exception e) {
                    android.util.Log.w("AccessibilityAgent", "Recording authorization failed; stopping", e);
                    main.post(() -> finishRecording());
                }
            }).start();
            main.postDelayed(() -> finishRecording(), MAX_DURATION_MS);
        } catch (Exception e) {
            String message = String.valueOf(e.getMessage()).replace('"', ' ');
            cleanup();
            reportError(recordId, message);
            showForeground("Recording failed: " + message, false);
            stopForeground(false);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void finishRecording() {
        if (stopping) return;
        stopping = true;
        isRecording = false;
        activeId = "";
        boolean valid = recorderStarted;
        try { if (recorderStarted) recorder.stop(); }
        catch (Exception e) { valid = false; }
        recorderStarted = false;
        cleanup();
        if (!valid || file == null || !file.isFile() || file.length() < 100) {
            reportError(recordId, "Recording too short or encoder failed");
            showForeground("Recording failed — try again", false);
            stopForeground(false);
            stopSelf();
            return;
        }
        final File uploadFile = file;
        final String id = recordId;
        getSharedPreferences("a", 0).edit()
                .putString("rec_file", uploadFile.getAbsolutePath())
                .putString("rec_id", id).apply();
        showForeground("Uploading MP4 to Device A...", false);
        new Thread(() -> {
            try { postJson("/record/uploading", "{\"recordId\":\"" + id + "\"}"); }
            catch (Exception ignored) {}
            upload(uploadFile, id);
        }).start();
    }

    private void upload(File video, String id) {
        try {
            if (video.length() > 20L * 1024 * 1024) throw new IOException("Video over 20MB; reduce duration");
            var pref = getSharedPreferences("a", 0);
            String base = pref.getString("s", ""), room = pref.getString("r", ""), token = pref.getString("t", "");
            HttpURLConnection c = (HttpURLConnection)new URL(base + "/api/agent/" + room + "/record/upload/" + id).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            c.setDoOutput(true);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Content-Type", "video/mp4");
            c.setFixedLengthStreamingMode(video.length());
            try (InputStream in = new FileInputStream(video); OutputStream out = c.getOutputStream()) {
                byte[] bytes = new byte[32 * 1024];
                int n;
                while ((n = in.read(bytes)) != -1) out.write(bytes, 0, n);
            }
            int response = c.getResponseCode();
            c.disconnect();
            if (response < 200 || response >= 300) throw new IOException("Upload HTTP " + response);
            video.delete();
            getSharedPreferences("a", 0).edit().remove("rec_file").remove("rec_id").apply();
            main.post(() -> {
                showForeground("Recording uploaded — download from Device A menu 17", false);
                stopForeground(false);
                stopSelf();
            });
        } catch (Exception e) {
            android.util.Log.e("AccessibilityAgent", "MP4 upload failed; local file retained", e);
            try {
                String safe = String.valueOf(e.getMessage()).replace("\\", " ").replace("\"", " ").replace("\n", " ");
                postJson("/record/upload_failed", "{\"recordId\":\"" + id + "\",\"message\":\"" + safe + "\"}");
            } catch (Exception ignored) {}
            main.post(() -> {
                showForeground("Upload failed — tap RETRY UPLOAD (video kept on B)", false);
                stopForeground(false);
                stopSelf();
            });
        }
    }

    private void retryUpload() {
        var pref = getSharedPreferences("a", 0);
        String name = pref.getString("rec_file", "");
        String id = pref.getString("rec_id", "");
        if (name.isEmpty() || id.isEmpty() || !new File(name).isFile()) { stopSelf(); return; }
        showForeground("Retrying MP4 upload...", false);
        new Thread(() -> upload(new File(name), id)).start();
    }

    private void cleanup() {
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) {}
            recorder.release(); recorder = null;
        }
        if (projection != null) {
            MediaProjection old = projection;
            projection = null;
            try { old.stop(); } catch (Exception ignored) {}
        }
    }

    private void reportError(String id, String message) {
        if (id == null) return;
        String safe = message.replace("\\", " ").replace("\"", " ").replace("\n", " ");
        new Thread(() -> { try { postJson("/record/error", "{\"recordId\":\"" + id + "\",\"message\":\"" + safe + "\"}"); }
                         catch (Exception ignored) {} }).start();
    }

    private void postJson(String suffix, String body) throws Exception {
        var pref = getSharedPreferences("a", 0);
        String base = pref.getString("s", ""), room = pref.getString("r", ""), token = pref.getString("t", "");
        HttpURLConnection c = (HttpURLConnection)new URL(base + "/api/agent/" + room + suffix).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(10000); c.setReadTimeout(10000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Content-Type", "application/json");
        try (OutputStream out = c.getOutputStream()) { out.write(body.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
        int result = c.getResponseCode(); c.disconnect();
        if (result < 200 || result >= 300) throw new IOException("Server HTTP " + result);
    }

    private void showForeground(String msg, boolean recording) {
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
                new NotificationChannel("record", "Screen recording", NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder n = new Notification.Builder(this, "record")
                .setSmallIcon(R.drawable.ic_status)
                .setContentTitle(recording ? "SCREEN RECORDING ACTIVE" : "Screen Recording")
                .setContentText(msg)
                .setOngoing(recording)
                .setOnlyAlertOnce(true);
        if (recording) {
            Intent stop = new Intent(this, RecordingService.class).setAction("STOP_RECORDING");
            PendingIntent pi = PendingIntent.getService(this, 45, stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            n.addAction(R.drawable.ic_status, "STOP RECORDING", pi);
        } else if (msg.startsWith("Upload failed")) {
            Intent retry = new Intent(this, RecordingService.class).setAction("RETRY_UPLOAD");
            PendingIntent pi = PendingIntent.getService(this, 46, retry,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            n.addAction(R.drawable.ic_status, "RETRY UPLOAD", pi);
        }
        Notification notification = n.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    recording ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                              : ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override public void onDestroy() {
        if (isRecording && !stopping) finishRecording();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
