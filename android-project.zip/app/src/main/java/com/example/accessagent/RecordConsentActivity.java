package com.example.accessagent;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;

/** User-facing consent gate. The system MediaProjection dialog is always required. */
public class RecordConsentActivity extends Activity {
    private static final int SCREEN_CONSENT = 401;
    private String recordId;
    private boolean answered;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        recordId = getIntent().getStringExtra("recordId");
        if (recordId == null || recordId.length() < 12) { finish(); return; }
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(24 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        TextView title = new TextView(this);
        title.setTextSize(22);
        title.setText("Device B: Screen recording permission");
        layout.addView(title);
        TextView explanation = new TextView(this);
        explanation.setTextSize(17);
        explanation.setText("Device A requested a 480p MP4 recording of your screen (no audio). Maximum 2 minutes. Video will be sent to Device A after recording. You can STOP at any time from the notification. Only approve if you want to share your screen.");
        explanation.setPadding(0,pad,0,pad);
        layout.addView(explanation);
        Button approve = new Button(this);
        approve.setText("ALLOW & OPEN ANDROID SCREEN CAPTURE PROMPT");
        layout.addView(approve, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button deny = new Button(this);
        deny.setText("DENY");
        layout.addView(deny);
        approve.setOnClickListener(v -> openSystemCapturePrompt());
        deny.setOnClickListener(v -> deny());
        setContentView(layout);
        // Trusted mode skips the extra in-app ALLOW button, but Android's
        // per-recording MediaProjection system prompt is still mandatory.
        if (getSharedPreferences("a", 0).getBoolean("trusted_session", false)) {
            layout.post(() -> openSystemCapturePrompt());
        }
    }

    private void openSystemCapturePrompt() {
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Enable notifications for Accessibility Agent before recording", Toast.LENGTH_LONG).show();
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 499);
                return;
            }
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            try { startActivityForResult(manager.createScreenCaptureIntent(), SCREEN_CONSENT); }
            catch (Exception e) { deny(); }
    }

    private void deny() {
        if (answered) return;
        answered = true;
        sendDenied(recordId);
        finish();
    }

    private void sendDenied(String id) {
        new Thread(() -> {
            try {
                var pref = getSharedPreferences("a", 0);
                String base = pref.getString("s", "");
                String room = pref.getString("r", "");
                String token = pref.getString("t", "");
                HttpURLConnection c = (HttpURLConnection)new URL(base + "/api/agent/" + room + "/record/denied").openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setDoOutput(true);
                c.setRequestProperty("Authorization", "Bearer " + token);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] payload = ("{\"recordId\":\"" + id + "\"}").getBytes(java.nio.charset.StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) { out.write(payload); }
                c.getResponseCode();
                c.disconnect();
            } catch (Exception ignored) {}
        }).start();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != SCREEN_CONSENT || answered) return;
        if (result != RESULT_OK || data == null) { deny(); return; }
        answered = true;
        Intent service = new Intent(this, RecordingService.class);
        service.setAction("START_RECORDING");
        service.putExtra("recordId", recordId);
        service.putExtra("captureResult", result);
        service.putExtra("captureData", data);
        try { startForegroundService(service); }
        catch (Exception e) { sendDenied(recordId); }
        finish();
    }

    @Override public void onBackPressed() { deny(); }
}
