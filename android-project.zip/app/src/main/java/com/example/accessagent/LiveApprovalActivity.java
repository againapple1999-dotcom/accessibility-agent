package com.example.accessagent;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;

public class LiveApprovalActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_live_approval);
        findViewById(R.id.live_allow).setOnClickListener(v -> decide(true));
        findViewById(R.id.live_deny).setOnClickListener(v -> decide(false));
    }

    private void decide(boolean allowed) {
        Intent intent = new Intent(this, AgentService.class);
        intent.setAction("DECIDE_LIVE");
        intent.putExtra("allow", allowed);
        startService(intent);
        finish();
    }
}
