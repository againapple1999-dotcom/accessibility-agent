package com.example.accessagent;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Device B: same account as Device A; local opt-in remains mandatory. */
public class MainActivity extends Activity {
    private EditText server, email, password, deviceName;
    private CheckBox trusted;
    private TextView status;
    private volatile boolean busy=false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        server=findViewById(R.id.server);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        deviceName=findViewById(R.id.deviceName);
        trusted=findViewById(R.id.trusted);
        status=findViewById(R.id.status);
        var p=getSharedPreferences("a",MODE_PRIVATE);
        server.setText(p.getString("s", ""));
        email.setText(p.getString("email", ""));
        deviceName.setText(p.getString("deviceName", "My Android"));
        // Never auto-enable remote control when a new account is configured.
        trusted.setChecked(p.getBoolean("trusted_session",false) && !SecureTokenStore.load(this).isEmpty());
        status.setText(SecureTokenStore.load(this).isEmpty()? "Not logged in" : "Login saved. Tap Start Agent to connect.");
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        findViewById(R.id.access).setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.login).setOnClickListener(v->login(false));
        findViewById(R.id.register).setOnClickListener(v->login(true));
        findViewById(R.id.start).setOnClickListener(v->startAgent());
        findViewById(R.id.stop).setOnClickListener(v->stopAgent());
        findViewById(R.id.logout).setOnClickListener(v->logout());
    }
    private String baseUrl() { return server.getText().toString().trim().replaceAll("/+$",""); }
    private boolean validUrl() {
        if (!baseUrl().startsWith("https://") || baseUrl().contains(" ")) {
            Toast.makeText(this,"HTTPS Server URL is required",Toast.LENGTH_LONG).show(); return false;
        }
        return true;
    }
    private void message(String m) { runOnUiThread(()->{status.setText(m);Toast.makeText(this,m,Toast.LENGTH_LONG).show();}); }
    private JSONObject post(String url, JSONObject body, String bearer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(10000);c.setReadTimeout(15000);
        c.setRequestProperty("Content-Type","application/json");
        if(!bearer.isEmpty()) c.setRequestProperty("Authorization","Bearer "+bearer);
        try(var out=c.getOutputStream()) {out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        int code=c.getResponseCode();
        InputStream input=code<400?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        if(input!=null) try(InputStream stream=input) {byte[] buffer=new byte[2048];int n;while((n=stream.read(buffer))!=-1)bytes.write(buffer,0,n);}
        c.disconnect();
        JSONObject response=new JSONObject(bytes.toString("UTF-8"));
        if(code<200 || code>=300) throw new Exception("HTTP "+code+": "+response.optString("error","server_error"));
        return response;
    }
    private void login(boolean register) {
        if(busy || !validUrl())return;
        // Changing account must first end any previous trusted agent session.
        stopAgent();
        String url=baseUrl(), mail=email.getText().toString().trim(), pw=password.getText().toString();
        if(mail.isEmpty() || pw.isEmpty()) {message("Enter email and password (at least 12 characters for registration)");return;}
        busy=true;status.setText(register?"Creating account...":"Logging in...");
        new Thread(()->{
            try {
                JSONObject body=new JSONObject().put("email",mail).put("password",pw);
                JSONObject response=post(url+"/api/account/"+(register?"register":"login"),body,"");
                String token=response.getString("sessionToken");
                // Store only the HTTPS URL and email as plain metadata; protect login token with Keystore.
                SecureTokenStore.save(this,token);
                getSharedPreferences("a",MODE_PRIVATE).edit().putString("s",url)
                        .putString("email",mail).putBoolean("trusted_session",false).apply();
                runOnUiThread(()->{password.setText("");trusted.setChecked(false);});
                message("Login saved. Turn on Trust if wanted, then tap Start Agent.");
            } catch(Exception e) { message("Login failed: "+e.getMessage()); }
            finally {busy=false;}
        },"account-login").start();
    }
    private void startAgent() {
        if(!validUrl())return;
        if(SecureTokenStore.load(this).isEmpty()) {message("Log in first.");return;}
        if(ControlService.I==null) {message("Enable Accessibility Service first.");return;}
        var prefs=getSharedPreferences("a",MODE_PRIVATE);
        String id=prefs.getString("deviceId","");
        if(id.isEmpty()) id=UUID.randomUUID().toString();
        prefs.edit().putString("deviceId",id).putString("s",baseUrl())
                .putString("deviceName",deviceName.getText().toString().trim())
                .putBoolean("trusted_session",trusted.isChecked()).apply();
        Intent i=new Intent(this,AgentService.class);i.setAction("START");
        try {
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
            status.setText("Connecting... Check the ongoing agent notification.");
        } catch(Exception e) {message("Could not start Agent: "+e.getMessage());}
    }
    private void stopAgent() {
        Intent i=new Intent(this,AgentService.class);i.setAction("STOP");
        try {startService(i);}catch(Exception ignored){}
        getSharedPreferences("a",MODE_PRIVATE).edit().putBoolean("trusted_session",false).apply();
        trusted.setChecked(false);
        status.setText("Disconnected. Login remains saved.");
    }
    private void logout() {
        if(busy)return;
        String token=SecureTokenStore.load(this);
        String url=getSharedPreferences("a",MODE_PRIVATE).getString("s","");
        stopAgent(); // immediate local remote-control stop regardless of connectivity
        if(token.isEmpty()) {status.setText("Logged out");return;}
        busy=true;
        status.setText("Disconnecting. Revoking account login on server...");
        new Thread(()->{
            try {
                post(url+"/api/account/logout",new JSONObject(),token);
                SecureTokenStore.clear(this);
                getSharedPreferences("a",MODE_PRIVATE).edit().remove("r").remove("t")
                        .remove("trusted_session").apply();
                runOnUiThread(()->{password.setText("");trusted.setChecked(false);});
                message("Logged out. This login was revoked on server.");
            } catch(Exception e) {
                message("Agent stopped, but server logout failed. Login kept so you can retry Logout when online.");
            } finally {busy=false;}
        },"account-logout").start();
    }

}
