package com.example.accessagent;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.EditText;
import android.widget.CheckBox;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText server;
    private EditText room;
    private EditText token;
    private CheckBox trusted;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        server = findViewById(R.id.server);
        room = findViewById(R.id.room);
        token = findViewById(R.id.token);
        trusted = findViewById(R.id.trusted);

        var prefs = getSharedPreferences("a", MODE_PRIVATE);
        server.setText(prefs.getString("s", ""));
        room.setText(prefs.getString("r", ""));
        token.setText(prefs.getString("t", ""));
        trusted.setChecked(prefs.getBoolean("trusted_session", false));
        // Any changed pairing requires Device B to explicitly opt in again.
        TextWatcher resetTrust = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                trusted.setChecked(false);
            }
            @Override public void afterTextChanged(Editable e) {}
        };
        server.addTextChangedListener(resetTrust);
        room.addTextChangedListener(resetTrust);
        token.addTextChangedListener(resetTrust);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    100
            );
        }

        findViewById(R.id.access).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );

        findViewById(R.id.start).setOnClickListener(v -> startAgent());

        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i = new Intent(this, AgentService.class);
            i.setAction("STOP");
            startService(i);
        });
    }

    private void startAgent() {
        String s = server.getText().toString().trim().replaceAll("/+$", "");
        String r = room.getText().toString().trim().toUpperCase();
        String t = token.getText().toString().trim();

        if (!s.startsWith("https://") || r.length() < 6 || t.length() < 20) {
            Toast.makeText(
                    this,
                    "Enter HTTPS server URL, room code, and agent token",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        getSharedPreferences("a", MODE_PRIVATE)
                .edit()
                .putString("s", s)
                .putString("r", r)
                .putString("t", t)
                .putBoolean("trusted_session", trusted.isChecked())
                .apply();

        Intent i = new Intent(this, AgentService.class);
        i.setAction("START");

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }
}
