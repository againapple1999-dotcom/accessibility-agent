package com.example.accessagent;

import android.content.Context;
import android.util.Base64;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.KeyStore;

/** Encrypt login tokens at rest using the Android Keystore. */
public final class SecureTokenStore {
    private static final String ALIAS = "accessagent-account-v1";
    private SecureTokenStore() {}
    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        SecretKey result = (SecretKey) ks.getKey(ALIAS, null);
        if (result != null) return result;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return kg.generateKey();
    }
    public static void save(Context context, String session) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        String ciphertext=Base64.encodeToString(cipher.doFinal(session.getBytes("UTF-8")), Base64.NO_WRAP);
        String iv=Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP);
        context.getSharedPreferences("a", Context.MODE_PRIVATE).edit()
                .putString("session_cipher", ciphertext).putString("session_iv", iv).apply();
    }
    public static String load(Context context) {
        try {
            var prefs=context.getSharedPreferences("a", Context.MODE_PRIVATE);
            String value=prefs.getString("session_cipher", "");
            String iv=prefs.getString("session_iv", "");
            if(value.isEmpty() || iv.isEmpty()) return "";
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(value, Base64.NO_WRAP)), "UTF-8");
        } catch (Exception e) { return ""; }
    }
    public static void clear(Context context) {
        context.getSharedPreferences("a", Context.MODE_PRIVATE).edit()
                .remove("session_cipher").remove("session_iv").apply();
    }
}
