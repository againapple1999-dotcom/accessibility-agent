package com.example.accessagent;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class AgentService extends Service {
    volatile boolean run = false, shown = false;
    volatile boolean shownLive = false, liveBlockedLocally = false, liveNotified = false;
    volatile boolean shownRecord = false;
    volatile boolean trustedConnection = false;
    long lastLiveSentMs = 0;
    ExecutorService loopEx = Executors.newSingleThreadExecutor();
    ExecutorService actionEx = Executors.newSingleThreadExecutor();
    String s="", r="", t="";
    volatile String accountSession="";
    long lastRebindAttemptMs=0;

    public int onStartCommand(Intent i, int f, int id) {
        String a = i == null ? "" : i.getAction();

        if ("STOP".equals(a)) {
            liveBlockedLocally = true;
            run = false;
            getSharedPreferences("a", 0).edit().putBoolean("trusted_session", false).apply();
            // Perform authenticated revoke before destroying the service, otherwise
            // onDestroy() would interrupt the asynchronous network task.
            new Thread(() -> {
                post("/api/agent/" + r + "/trust/revoke", new JSONObject());
                stopSelf();
            }, "disconnect-agent").start();
            if (RecordingService.isRecording) {
                Intent stopRecord = new Intent(this, RecordingService.class);
                stopRecord.setAction("STOP_RECORDING");
                startService(stopRecord);
            }
            stopForeground(true);
            return START_NOT_STICKY;
        }

        if ("STOP_LIVE".equals(a)) {
            // Immediate local stop even when the network is unavailable.
            liveBlockedLocally = true;
            liveNotified = false;
            updateNotification("Agent ready - screen sharing stopped", false);
            actionEx.execute(() -> post("/api/agent/" + r + "/live/stop", new JSONObject()));
            return START_NOT_STICKY;
        }

        if ("DECIDE_LIVE".equals(a)) {
            boolean allow = i.getBooleanExtra("allow", false);
            actionEx.execute(() -> {
                JSONObject body = new JSONObject();
                try { body.put("allow", allow); } catch (JSONException ignored) {}
                JSONObject reply = post("/api/agent/" + r + "/live/decision", body);
                if (reply.optBoolean("ok", false) && allow) {
                    liveBlockedLocally = false;
                    lastLiveSentMs = 0;
                } else {
                    liveBlockedLocally = true;
                }
                shownLive = false;
            });
            return START_NOT_STICKY;
        }

        if ("DECIDE".equals(a)) {
            boolean allow = i.getBooleanExtra("allow", false);

            // ALLOW/DENY must use a different executor from the long-running poll loop.
            actionEx.execute(() -> {
                JSONObject body = new JSONObject();
                try { body.put("allow", allow); } catch (JSONException ignored) {}
                post("/api/agent/" + r + "/decision", body);
                shown = false;
            });
            return START_NOT_STICKY;
        }

        if ("START".equals(a) && !run) {
            var p = getSharedPreferences("a", 0);
            s = p.getString("s", "");
            r = p.getString("r", "");
            t = p.getString("t", "");
            accountSession = SecureTokenStore.load(this);

            // Android 14+ requires an explicit foreground service type.
            // This agent maintains a user-approved connection for data transfer.
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n("Accessibility Agent running"),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(1, n("Accessibility Agent running"));
            }
            run = true;
            loopEx.execute(this::loop);
        }

        return START_NOT_STICKY;
    }

    /** Account login replaces manual room/token entry. Refresh pairing after server restart. */
    boolean refreshDeviceRegistration() {
        if(!run || accountSession.isEmpty()) return false;
        try {
            var p=getSharedPreferences("a",0);
            JSONObject body=new JSONObject();
            body.put("deviceId",p.getString("deviceId",""));
            body.put("deviceName",p.getString("deviceName","My Android"));
            HttpURLConnection c=(HttpURLConnection)new URL(s+"/api/account/device/register").openConnection();
            c.setRequestMethod("POST");c.setConnectTimeout(10000);c.setReadTimeout(15000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json");
            c.setRequestProperty("Authorization","Bearer "+accountSession);
            try(OutputStreamWriter w=new OutputStreamWriter(c.getOutputStream())){w.write(body.toString());}
            JSONObject response=read(c);
            String newRoom=response.getString("roomCode"), newToken=response.getString("agentToken");
            // Publish both credentials together on the same worker thread.
            r=newRoom; t=newToken;
            p.edit().putString("r",r).putString("t",t).apply();
            JSONObject registration=post("/api/agent/"+r+"/register",new JSONObject());
            if(!registration.optBoolean("ok",false))return false;
            trustedConnection=false;
            if(ControlService.I!=null && p.getBoolean("trusted_session",false)) {
                JSONObject trust=new JSONObject().put("trusted",true);
                JSONObject reply=post("/api/agent/"+r+"/trust",trust);
                trustedConnection=reply.optBoolean("trusted",false);
            }
            updateNotification(trustedConnection?"TRUSTED account connected - tap to disconnect":"Agent online",false);
            android.util.Log.i("AccessibilityAgent","Device registered to signed-in account");
            return true;
        } catch(Exception e) {
            android.util.Log.w("AccessibilityAgent","Account pairing failed; retrying",e);
            updateNotification("Could not connect - check server/login",false);
            return false;
        }
    }

    void loop() {
        refreshDeviceRegistration();
        while (run) {
            try {
                if(r.isEmpty()) {
                    Thread.sleep(3000);
                    refreshDeviceRegistration();
                    continue;
                }
                JSONObject j;
                try {j=get("/api/agent/" + r + "/poll");}
                catch(Exception pollError) {
                    long time=android.os.SystemClock.elapsedRealtime();
                    if(time-lastRebindAttemptMs>8000) {
                        lastRebindAttemptMs=time;
                        refreshDeviceRegistration();
                    }
                    throw pollError;
                }

                if (j.optBoolean("pending") && !shown) {
                    shown = true;
                    Intent approval = new Intent(this, ApprovalActivity.class);
                    approval.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(approval);
                }

                JSONObject rec = j.optJSONObject("record");
                if (rec != null) {
                    String recordId = rec.optString("id", "");
                    if (rec.optBoolean("pending") && !shownRecord && !recordId.isEmpty()) {
                        shownRecord = true;
                        Intent prompt = new Intent(this, RecordConsentActivity.class);
                        prompt.putExtra("recordId", recordId);
                        prompt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                            new NotificationChannel("record_approval", "Recording approval", NotificationManager.IMPORTANCE_HIGH));
                        PendingIntent pi = PendingIntent.getActivity(this, 303, prompt,
                                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                        Notification notice = new Notification.Builder(this, "record_approval")
                            .setSmallIcon(R.drawable.ic_status)
                            .setContentTitle("Device A requests screen recording")
                            .setContentText("Tap to allow or deny 480p MP4 recording")
                            .setContentIntent(pi).setAutoCancel(true).build();
                        nm.notify(3, notice);
                        try { startActivity(prompt); } catch (Exception ignored) { /* notification fallback */ }
                    } else if (!rec.optBoolean("pending")) {
                        shownRecord = false;
                        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(3);
                    }
                    if (rec.optBoolean("stopRequested") && RecordingService.isRecording
                            && recordId.equals(RecordingService.activeId)) {
                        Intent stop = new Intent(this, RecordingService.class);
                        stop.setAction("STOP_RECORDING");
                        startService(stop);
                    }
                }

                JSONObject live = j.optJSONObject("live");
                boolean livePending = live != null && live.optBoolean("pending");
                boolean liveActive = live != null && live.optBoolean("active");
                if (livePending && !shownLive) {
                    shownLive = true;
                    if (trustedConnection) {
                        actionEx.execute(() -> {
                            JSONObject body = new JSONObject();
                            try { body.put("allow", true); } catch (JSONException ignored) {}
                            JSONObject reply = post("/api/agent/" + r + "/live/decision", body);
                            if (reply.optBoolean("ok", false)) {
                                liveBlockedLocally = false;
                                lastLiveSentMs = 0;
                            }
                        });
                    } else {
                        updateNotification("Tap to approve LIVE screen sharing", false, true);
                        Intent approval = new Intent(this, LiveApprovalActivity.class);
                        approval.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try { startActivity(approval); } catch (Exception ignored) {}
                    }
                } else if (!livePending) {
                    shownLive = false;
                }

                if (j.optBoolean("approved")
                        && j.has("command")
                        && !j.isNull("command")) {
                    cmd(j.getJSONObject("command"));
                }

                boolean streamNow = liveActive && !liveBlockedLocally;
                if (streamNow != liveNotified) {
                    liveNotified = streamNow;
                    updateNotification(streamNow ? "LIVE screen sharing with Device A - tap to stop" :
                            trustedConnection ? "TRUSTED controller connected - tap to stop" : "Agent ready", streamNow);
                }
                if (streamNow && ControlService.I != null) {
                    long timestamp = android.os.SystemClock.elapsedRealtime();
                    int intervalMs = Math.max(1500, live.optInt("intervalMs", 2500));
                    if (timestamp - lastLiveSentMs >= intervalMs) {
                        lastLiveSentMs = timestamp;
                        sendLiveFrame();
                    }
                }
                Thread.sleep(2000); // P5 stable URL: protect Workers Free request quota
            } catch (Exception e) {
                try { Thread.sleep(2000); } catch (Exception ignored) {}
            }
        }
    }

    void sendLiveFrame() {
        if (liveBlockedLocally || !run) return;
        try {
            long start = android.os.SystemClock.elapsedRealtime();
            String jpeg = ControlService.I.screenshotDataUrl();
            if (liveBlockedLocally || !run) return;
            JSONObject body = new JSONObject();
            body.put("imageData", jpeg);
            JSONObject reply = post("/api/agent/" + r + "/live/frame", body);
            android.util.Log.i("AccessibilityAgent", "Live preview frame: " +
                    (android.os.SystemClock.elapsedRealtime() - start) +
                    "ms; uploaded=" + reply.optBoolean("ok", false));
        } catch (Exception e) {
            android.util.Log.w("AccessibilityAgent", "Live preview capture failed", e);
        }
    }

    void updateNotification(String label, boolean streaming) {
        updateNotification(label, streaming, false);
    }

    void updateNotification(String label, boolean streaming, boolean pendingApproval) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                .notify(1, n(label, streaming, pendingApproval));
    }

    void cmd(JSONObject c) {
        String id = c.optString("id");
        String type = c.optString("type");
        JSONObject p = c.optJSONObject("payload");
        if (p == null) p = new JSONObject();

        ControlService a = ControlService.I;
        boolean ok = false;
        String m = "";
        String imageData = null;

        try {
            if (a == null) throw new Exception("Accessibility not enabled");

            switch (type) {
                case "home":
                    ok = a.home(); m = "Home"; break;
                case "back":
                    ok = a.back(); m = "Back"; break;
                case "tap":
                    ok = a.tap((float)p.optDouble("x"), (float)p.optDouble("y"));
                    m = "Tap"; break;
                case "swipe":
                    ok = a.swipe(
                            (float)p.optDouble("x1"), (float)p.optDouble("y1"),
                            (float)p.optDouble("x2"), (float)p.optDouble("y2"),
                            p.optLong("duration", 350));
                    m = "Swipe"; break;
                case "text":
                    ok = a.text(p.optString("text", ""));
                    m = ok ? "Text" : "No editable focused field";
                    break;
                case "click_text":
                    ok = a.clickText(p.optString("text", ""));
                    m = ok ? "UI text clicked" : "Matching clickable UI not found";
                    break;
                case "current_app":
                    String pkg = a.currentPackage();
                    ok = !pkg.isEmpty();
                    m = ok ? pkg : "Current package unavailable";
                    break;
                case "screenshot":
                    long captureStart = android.os.SystemClock.elapsedRealtime();
                    imageData = a.screenshotDataUrl();
                    ok = imageData != null;
                    m = "Screenshot captured";
                    android.util.Log.i("AccessibilityAgent", "Screenshot capture+JPEG: "
                            + (android.os.SystemClock.elapsedRealtime() - captureStart)
                            + "ms, base64 chars: " + (imageData == null ? 0 : imageData.length()));
                    break;
                default:
                    m = "Unsupported command";
            }
        } catch (Exception e) {
            m = e.getMessage();
        }

        JSONObject body = new JSONObject();
        try {
            body.put("commandId", id);
            body.put("ok", ok);
            body.put("message", m);
            if (imageData != null) body.put("imageData", imageData);
        } catch (JSONException ignored) {}

        long uploadStart = android.os.SystemClock.elapsedRealtime();
        JSONObject reply = post("/api/agent/" + r + "/result", body);
        if ("screenshot".equals(type)) {
            android.util.Log.i("AccessibilityAgent", "Screenshot result POST: "
                    + (android.os.SystemClock.elapsedRealtime() - uploadStart)
                    + "ms, server OK: " + reply.optBoolean("ok", false));
        }
    }

    JSONObject get(String p) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(s + p).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Authorization", "Bearer " + t);
        return read(c);
    }

    JSONObject post(String p, JSONObject b) {
        try {
            HttpURLConnection c = (HttpURLConnection)new URL(s + p).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Authorization", "Bearer " + t);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStreamWriter w = new OutputStreamWriter(c.getOutputStream())) {
                w.write(b.toString());
            }
            return read(c);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    JSONObject read(HttpURLConnection c) throws Exception {
        int status = c.getResponseCode();
        InputStream in = status >= 200 && status < 300 ? c.getInputStream() : c.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        StringBuilder x = new StringBuilder();
        String l;
        while ((l = br.readLine()) != null) x.append(l);
        if (status < 200 || status >= 300) throw new IOException("HTTP " + status + ": " + x);
        return new JSONObject(x.toString());
    }

    Notification n(String x) { return n(x, false, false); }

    Notification n(String x, boolean streaming, boolean pendingApproval) {
        if (Build.VERSION.SDK_INT >= 26) {
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(new NotificationChannel(
                            "a", "Accessibility Agent", NotificationManager.IMPORTANCE_LOW));
        }

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "a")
                : new Notification.Builder(this);

        b.setContentTitle(streaming ? "LIVE SCREEN SHARING ACTIVE" : "Accessibility Agent")
                .setContentText(x)
                .setSmallIcon(R.drawable.ic_status)
                .setOngoing(true);
        if (streaming) {
            Intent stop = new Intent(this, AgentService.class);
            stop.setAction("STOP_LIVE");
            PendingIntent pi = PendingIntent.getService(this, 101, stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(R.drawable.ic_status, "STOP SHARING", pi);
        }
        if (trustedConnection) {
            Intent disconnect = new Intent(this, AgentService.class);
            disconnect.setAction("STOP");
            PendingIntent di = PendingIntent.getService(this, 103, disconnect,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(R.drawable.ic_status, "DISCONNECT", di);
        }
        if (pendingApproval) {
            Intent show = new Intent(this, LiveApprovalActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 102, show,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.setContentIntent(pi);
        }
        return b.build();
    }

    @Override
    public void onDestroy() {
        run = false;
        if (RecordingService.isRecording) {
            Intent stop = new Intent(this, RecordingService.class);
            stop.setAction("STOP_RECORDING");
            try { startService(stop); } catch (Exception ignored) {}
        }
        loopEx.shutdownNow();
        actionEx.shutdownNow();
        super.onDestroy();
    }

    public android.os.IBinder onBind(Intent i) { return null; }
}
